package com.example.wcmp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.*;

public class Login extends AppCompatActivity {

    EditText username, password;
    Button login, signup;
    ImageView warningIcon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        username = findViewById(R.id.username2);
        password = findViewById(R.id.password2);
        login = findViewById(R.id.btn_login2);
        signup = findViewById(R.id.btn_signup2);
        warningIcon = findViewById(R.id.passwordWarningIcon);

        login.setOnClickListener(view -> {
            if (!validateUsername() | !validatePassword()) {
                Toast.makeText(Login.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            } else {
                warningIcon.setVisibility(View.GONE);
                checkUser();
            }
        });

        signup.setOnClickListener(view -> {
            Intent intent = new Intent(Login.this, Signup.class);
            startActivity(intent);
        });
    }

    public Boolean validateUsername() {
        String val = username.getText().toString();
        if (val.isEmpty()) {
            username.setError("Empty field!");
            return false;
        } else {
            username.setError(null);
            return true;
        }
    }

    public Boolean validatePassword() {
        String val = password.getText().toString();
        if (val.isEmpty()) {
            password.setError("Empty field!");
            return false;
        } else {
            password.setError(null);
            return true;
        }
    }

    public void checkUser() {
        String user = username.getText().toString().trim();
        String pass = password.getText().toString().trim();

        DatabaseReference adminRef = FirebaseDatabase
                .getInstance("https://wcmp-53d93-default-rtdb.firebaseio.com/")
                .getReference("admins");

        adminRef.child(user).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String adminPass = snapshot.child("password").getValue(String.class);
                    if (adminPass != null && adminPass.equals(pass)) {
                        warningIcon.setVisibility(View.GONE);
                        startActivity(new Intent(Login.this, admin.class));
                    } else {
                        password.setError("Invalid admin password");
                        warningIcon.setVisibility(View.VISIBLE);
                        password.requestFocus();
                    }
                } else {
                    checkRegularUser(user, pass);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(Login.this, "Database error", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void checkRegularUser(String user, String pass) {
        DatabaseReference reference = FirebaseDatabase
                .getInstance("https://wcmp-53d93-default-rtdb.firebaseio.com/")
                .getReference("users");

        Query checkUserDatabase = reference.orderByChild("username").equalTo(user);
        checkUserDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    for (DataSnapshot userSnapshot : snapshot.getChildren()) {
                        String passFromDB = userSnapshot.child("password").getValue(String.class);
                        if (passFromDB != null && passFromDB.equals(pass)) {
                            String fn = userSnapshot.child("firstname").getValue(String.class);
                            String ln = userSnapshot.child("lastname").getValue(String.class);
                            String dob = userSnapshot.child("dateofbirth").getValue(String.class);
                            String pn = userSnapshot.child("phonenum").getValue(String.class);
                            String em = userSnapshot.child("email").getValue(String.class);
                            String usern = userSnapshot.child("username").getValue(String.class);

                            getSharedPreferences("user_pref", MODE_PRIVATE).edit()
                                    .putString("currentUser", usern).apply();

                            warningIcon.setVisibility(View.GONE);
                            Intent intent = new Intent(Login.this, Profile.class);
                            intent.putExtra("firstname", fn);
                            intent.putExtra("lastname", ln);
                            intent.putExtra("dateofbirth", dob);
                            intent.putExtra("phonenum", pn);
                            intent.putExtra("username", usern);
                            intent.putExtra("email", em);
                            startActivity(intent);
                            return;
                        }
                    }
                    password.setError("Invalid credentials");
                    warningIcon.setVisibility(View.VISIBLE);
                    password.requestFocus();
                } else {
                    username.setError("User does not exist");
                    warningIcon.setVisibility(View.GONE);
                    username.requestFocus();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(Login.this, "Database error", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
