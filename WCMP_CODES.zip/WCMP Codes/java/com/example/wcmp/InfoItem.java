package com.example.wcmp;

public class InfoItem {
    private String id;
    private String text;
    private String url;  // New field for URL

    // Empty constructor required for Firebase
    public InfoItem() {}

    // Constructor with parameters
    public InfoItem(String id, String text, String url) {
        this.id = id;
        this.text = text;
        this.url = url;
    }

    // Getter methods
    public String getId() {
        return id;
    }

    public String getText() {
        return text;
    }

    public String getUrl() {
        return url;
    }

    // Setter methods
    public void setId(String id) {
        this.id = id;
    }

    public void setText(String text) {
        this.text = text;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
