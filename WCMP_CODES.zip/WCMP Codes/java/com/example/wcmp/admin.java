package com.example.wcmp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;

public class admin extends AppCompatActivity {

    LinearLayout modifyContainer, infoContainer, databaseContainer;
    Button logout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        // Linking bubbles
        modifyContainer = findViewById(R.id.modifyContainer);
        infoContainer = findViewById(R.id.infoContainer);
        databaseContainer = findViewById(R.id.databaseContainer);

        logout = findViewById(R.id.logout);

        // Modify bubble click
        modifyContainer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(admin.this, modify.class);
                startActivity(intent);
            }
        });

        // Info bubble click
        infoContainer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(admin.this, info.class);
                startActivity(intent);
            }
        });

        // Database bubble click - open Firebase URL
        databaseContainer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://console.firebase.google.com/u/0/project/wcmp-53d93/database/wcmp-53d93-default-rtdb/data";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(intent);
            }
        });

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(admin.this, Login.class);
                startActivity(intent);
            }
        });
    }
}
