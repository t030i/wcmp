package com.example.wcmp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.*;

import java.util.ArrayList;
import java.util.List;

public class tips extends AppCompatActivity {

    RecyclerView recyclerView;
    TipAdapter adapter;
    List<InfoItem> tipList;
    DatabaseReference tipRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tips);

        Button homeButton = findViewById(R.id.homeButton);
        Button profileButton = findViewById(R.id.profileButton);
        Button helpButton = findViewById(R.id.helpButton);
        recyclerView = findViewById(R.id.recyclerViewTips);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        tipList = new ArrayList<>();
        adapter = new TipAdapter(this, tipList);
        recyclerView.setAdapter(adapter);

        tipRef = FirebaseDatabase.getInstance().getReference("tips");

        tipRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                tipList.clear();
                for (DataSnapshot child : snapshot.getChildren()) {
                    InfoItem item = child.getValue(InfoItem.class);
                    if (item != null) {
                        tipList.add(item);
                    }
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(tips.this, "Failed to load tips.", Toast.LENGTH_SHORT).show();
            }
        });

        homeButton.setOnClickListener(view -> startActivity(new Intent(tips.this, Home.class)));
        profileButton.setOnClickListener(view -> startActivity(new Intent(tips.this, Profile.class)));
        helpButton.setOnClickListener(view -> startActivity(new Intent(tips.this, guidepage.class)));
    }
}
