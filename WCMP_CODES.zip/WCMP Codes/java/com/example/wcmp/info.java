package com.example.wcmp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class info extends AppCompatActivity {

    private TextView usersCount, adminsCount, feedbacksCount, eventsCount, tipsCount, messagesCount, issuesCount, dealsCount;
    private Button backButton;

    private final String DB_URL = "https://wcmp-53d93-default-rtdb.firebaseio.com/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);

        FirebaseApp.initializeApp(this);

        usersCount = findViewById(R.id.usersCount);
        adminsCount = findViewById(R.id.adminsCount);
        feedbacksCount = findViewById(R.id.feedbacksCount);
        eventsCount = findViewById(R.id.eventsCount);
        tipsCount = findViewById(R.id.tipsCount);
        messagesCount = findViewById(R.id.messagesCount);
        issuesCount = findViewById(R.id.issuesCount);
        dealsCount = findViewById(R.id.dealsCount);
        backButton = findViewById(R.id.back_button);

        backButton.setOnClickListener(v -> {
            Intent intent = new Intent(info.this, admin.class);
            startActivity(intent);
            finish();
        });

        loadCount("users", usersCount);
        loadCount("admins", adminsCount);
        loadCount("feedbacks", feedbacksCount);
        loadCount("events", eventsCount);
        loadCount("tips", tipsCount);
        loadCount("group_chat", messagesCount);
        loadCount("reports", issuesCount);
        loadCount("deals", dealsCount);
    }

    private void loadCount(String nodeName, TextView targetTextView) {
        DatabaseReference ref = FirebaseDatabase
                .getInstance(DB_URL)
                .getReference(nodeName);

        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                long count = snapshot.getChildrenCount();
                targetTextView.setText(formatLabel(nodeName) + ": " + count);
                Log.d("FIREBASE_COUNT", nodeName + " = " + count);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                targetTextView.setText(formatLabel(nodeName) + ": error");
                Log.e("FIREBASE_ERROR", "Failed to read " + nodeName + ": " + error.getMessage());
            }
        });
    }

    private String formatLabel(String rawNodeName) {
        switch (rawNodeName) {
            case "group_chat": return "Messages";
            case "admins": return "Admins";
            case "users": return "Users";
            case "feedbacks": return "Feedbacks";
            case "events": return "Events";
            case "tips": return "Tips";
            case "reports": return "Issues";
            case "deals": return "Deals";
            default: return rawNodeName;
        }
    }
}
