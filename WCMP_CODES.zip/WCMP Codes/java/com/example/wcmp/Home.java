package com.example.wcmp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class Home extends AppCompatActivity {

    private RecyclerView recyclerView;
    private CommunityAdapter adapter;
    private List<String> communityPosts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // Initialize RecyclerView
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Sample Data for Community Section
        communityPosts = new ArrayList<>();
        communityPosts.add("Upcoming Event: Women's Leadership Workshop!");
        communityPosts.add("New Deals: Local shopping discounts available now.");
        communityPosts.add("Tips: Managing home and work balance efficiently.");
        communityPosts.add("Stay connected: Chat with our community!");

        // Pass Context and Community Posts to the Adapter
        adapter = new CommunityAdapter(Home.this, communityPosts);  // Pass Home.this as Context
        recyclerView.setAdapter(adapter);

        // Set up Bottom Navigation
        Button homeButton = findViewById(R.id.homepage1);
        Button profileButton = findViewById(R.id.profilepage1);
        Button helpButton = findViewById(R.id.helpservice);

        homeButton.setOnClickListener(view -> {
            // Reload home or add behavior if needed
        });

        profileButton.setOnClickListener(view -> {
            Intent intent = new Intent(Home.this, Profile.class);
            startActivity(intent);
        });

        helpButton.setOnClickListener(view -> {
            Intent intent = new Intent(Home.this, guidepage.class);
            startActivity(intent);
        });
    }
}
