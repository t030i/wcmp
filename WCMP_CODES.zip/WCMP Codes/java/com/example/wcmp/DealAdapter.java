package com.example.wcmp;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.*;
import android.widget.*;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class DealAdapter extends RecyclerView.Adapter<DealAdapter.ViewHolder> {

    private final List<InfoItem> deals;
    private final Context context;

    public DealAdapter(Context context, List<InfoItem> deals) {
        this.context = context;
        this.deals = deals;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView text;
        Button viewMoreBtn;

        public ViewHolder(View itemView) {
            super(itemView);
            text = itemView.findViewById(R.id.eventItemText);
            viewMoreBtn = itemView.findViewById(R.id.viewMoreButton);
        }
    }

    @NonNull
    @Override
    public DealAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.event_item, parent, false); // Reuse the same layout
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DealAdapter.ViewHolder holder, int position) {
        InfoItem item = deals.get(position);
        holder.text.setText(item.getText());

        holder.viewMoreBtn.setOnClickListener(v -> {
            String url = item.getUrl();
            if (url != null && !url.trim().isEmpty()) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                context.startActivity(intent);
            } else {
                Toast.makeText(context, "No link available for this deal.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return deals.size();
    }
}

