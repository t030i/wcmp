package com.example.wcmp;

public class FeedbackModel {
    public String message;
    public float rating;

    public FeedbackModel() {
        // Default constructor for Firebase
    }

    public FeedbackModel(String message, float rating) {
        this.message = message;
        this.rating = rating;
    }
}

