package com.example.wcmp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class modify extends AppCompatActivity {

    EditText eventInput, eventUrlInput, dealInput, dealUrlInput, tipInput, tipUrlInput;
    Button submitEventBtn, submitDealBtn, submitTipBtn;
    DatabaseReference eventRef, dealRef, tipRef;

    RecyclerView eventRecycler, dealRecycler, tipRecycler;
    List<InfoItem> eventList, dealList, tipList;
    InfoAdapter eventAdapter, dealAdapter, tipAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modify);

        // Inputs
        eventInput = findViewById(R.id.eventInput);
        eventUrlInput = findViewById(R.id.eventUrlInput);
        dealInput = findViewById(R.id.dealInput);
        dealUrlInput = findViewById(R.id.dealUrlInput);
        tipInput = findViewById(R.id.tipInput);
        tipUrlInput = findViewById(R.id.tipUrlInput);

        // Buttons
        submitEventBtn = findViewById(R.id.submitEventBtn);
        submitDealBtn = findViewById(R.id.submitDealBtn);
        submitTipBtn = findViewById(R.id.submitTipBtn);

        // Firebase Refs
        eventRef = FirebaseDatabase.getInstance().getReference("events");
        dealRef = FirebaseDatabase.getInstance().getReference("deals");
        tipRef = FirebaseDatabase.getInstance().getReference("tips");

        // RecyclerViews
        eventRecycler = findViewById(R.id.eventRecycler);
        dealRecycler = findViewById(R.id.dealRecycler);
        tipRecycler = findViewById(R.id.tipRecycler);

        // Lists
        eventList = new ArrayList<>();
        dealList = new ArrayList<>();
        tipList = new ArrayList<>();

        // Adapters
        eventAdapter = new InfoAdapter(this, eventList, eventRef);
        dealAdapter = new InfoAdapter(this, dealList, dealRef);
        tipAdapter = new InfoAdapter(this, tipList, tipRef);

        // Set Layout Managers and Adapters
        eventRecycler.setLayoutManager(new LinearLayoutManager(this));
        eventRecycler.setAdapter(eventAdapter);

        dealRecycler.setLayoutManager(new LinearLayoutManager(this));
        dealRecycler.setAdapter(dealAdapter);

        tipRecycler.setLayoutManager(new LinearLayoutManager(this));
        tipRecycler.setAdapter(tipAdapter);

        // Load Firebase data
        loadFromFirebase(eventRef, eventList, eventAdapter);
        loadFromFirebase(dealRef, dealList, dealAdapter);
        loadFromFirebase(tipRef, tipList, tipAdapter);

        // Submit Event
        submitEventBtn.setOnClickListener(v -> {
            String text = eventInput.getText().toString().trim();
            String url = eventUrlInput.getText().toString().trim();
            if (!text.isEmpty()) {
                String id = eventRef.push().getKey();
                InfoItem item = new InfoItem(id, text, url);
                eventRef.child(id).setValue(item);
                Toast.makeText(modify.this, "Event submitted!", Toast.LENGTH_SHORT).show();
                eventInput.setText("");
                eventUrlInput.setText("");
            } else {
                Toast.makeText(modify.this, "Please enter an event.", Toast.LENGTH_SHORT).show();
            }
        });

        // Submit Deal
        submitDealBtn.setOnClickListener(v -> {
            String text = dealInput.getText().toString().trim();
            String url = dealUrlInput.getText().toString().trim();
            if (!text.isEmpty()) {
                String id = dealRef.push().getKey();
                InfoItem item = new InfoItem(id, text, url);
                dealRef.child(id).setValue(item);
                Toast.makeText(modify.this, "Deal submitted!", Toast.LENGTH_SHORT).show();
                dealInput.setText("");
                dealUrlInput.setText("");
            } else {
                Toast.makeText(modify.this, "Please enter a deal.", Toast.LENGTH_SHORT).show();
            }
        });

        // Submit Tip
        submitTipBtn.setOnClickListener(v -> {
            String text = tipInput.getText().toString().trim();
            String url = tipUrlInput.getText().toString().trim();
            if (!text.isEmpty()) {
                String id = tipRef.push().getKey();
                InfoItem item = new InfoItem(id, text, url);
                tipRef.child(id).setValue(item);
                Toast.makeText(modify.this, "Tip submitted!", Toast.LENGTH_SHORT).show();
                tipInput.setText("");
                tipUrlInput.setText("");
            } else {
                Toast.makeText(modify.this, "Please enter a tip.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Reusable method to load data
    private void loadFromFirebase(DatabaseReference ref, List<InfoItem> list, InfoAdapter adapter) {
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                list.clear();
                for (DataSnapshot snap : snapshot.getChildren()) {
                    InfoItem item = snap.getValue(InfoItem.class);
                    list.add(item);
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(modify.this, "Failed to load data", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
