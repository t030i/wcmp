package com.example.wcmp;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class guidepage extends AppCompatActivity {


    LinearLayout feedbackBubble, reportBubble, contactBubble;
    DatabaseReference feedbackRef, reportRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guide_page);

        // Bottom navigation
        Button homepageBtn = findViewById(R.id.homepage1);
        Button profilepageBtn = findViewById(R.id.profilepage1);

        // Bubbles
        feedbackBubble = findViewById(R.id.feedbackBubble);
        reportBubble = findViewById(R.id.reportBubble);
        contactBubble = findViewById(R.id.contactBubble);

        // Firebase references
        FirebaseDatabase database = FirebaseDatabase.getInstance("https://wcmp-53d93-default-rtdb.firebaseio.com/");
        feedbackRef = database.getReference("feedbacks");
        reportRef = database.getReference("reports");

        // Navigation
        homepageBtn.setOnClickListener(v -> startActivity(new Intent(guidepage.this, Home.class)));
        profilepageBtn.setOnClickListener(v -> startActivity(new Intent(guidepage.this, Profile.class)));

        // Bubble click listeners
        feedbackBubble.setOnClickListener(v -> showFeedbackDialog());
        reportBubble.setOnClickListener(v -> showReportDialog());
        contactBubble.setOnClickListener(v -> showContactDialog());
    }

    private void showFeedbackDialog() {
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_feedback, null);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(view);

        EditText feedbackText = view.findViewById(R.id.feedbackText);
        RatingBar ratingBar = view.findViewById(R.id.ratingBar);
        TextView closeFeedBackDialog = view.findViewById(R.id.closeFeedBackDialog);
        View submit = view.findViewById(R.id.submitFeedback);

        AlertDialog dialog = builder.create();
        dialog.show();

        closeFeedBackDialog.setOnClickListener(v -> dialog.dismiss());

        submit.setOnClickListener(v -> {
            String message = feedbackText.getText().toString().trim();
            float rating = ratingBar.getRating();

            if (message.isEmpty()) {
                Toast.makeText(this, "Please enter feedback text", Toast.LENGTH_SHORT).show();
            } else {
                String feedbackId = feedbackRef.push().getKey();
                FeedbackModel model = new FeedbackModel(message, rating);
                feedbackRef.child(feedbackId).setValue(model);
                Toast.makeText(this, "Feedback submitted. Thank you!", Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            }
        });
    }

    private void showReportDialog() {
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_report, null);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(view);

        EditText issueText = view.findViewById(R.id.issueText);
        View submit = view.findViewById(R.id.submitIssue);
        TextView closeReportDialog = view.findViewById(R.id.closeReportDialog);

        AlertDialog dialog = builder.create();
        dialog.show();

        closeReportDialog.setOnClickListener(v -> dialog.dismiss());

        submit.setOnClickListener(v -> {
            String issue = issueText.getText().toString().trim();

            if (issue.isEmpty()) {
                Toast.makeText(this, "Please describe the issue", Toast.LENGTH_SHORT).show();
            } else {
                String reportId = reportRef.push().getKey();
                ReportModel model = new ReportModel(issue);
                reportRef.child(reportId).setValue(model);
                Toast.makeText(this, "Issue reported. We’ll look into it!", Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            }
        });
    }

    private void showContactDialog() {
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_contact, null);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(view);

        AlertDialog dialog = builder.create();
        dialog.show();

        TextView closeContactDialog = view.findViewById(R.id.closeContactDialog);
        closeContactDialog.setOnClickListener(v -> dialog.dismiss());
    }
}
