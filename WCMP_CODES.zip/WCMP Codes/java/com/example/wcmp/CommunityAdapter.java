package com.example.wcmp;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CommunityAdapter extends RecyclerView.Adapter<CommunityAdapter.ViewHolder> {

    private List<String> communityPosts;
    private Context context;

    // Updated constructor to accept context as well
    public CommunityAdapter(Context context, List<String> communityPosts) {
        this.context = context;
        this.communityPosts = communityPosts;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_community_post, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        String post = communityPosts.get(position);
        holder.postTextView.setText(post);

        // Set click listener
        holder.itemView.setOnClickListener(v -> {
            if (post.contains("Upcoming Event: Women's Leadership Workshop!")) {
                Intent intent = new Intent(context, events.class);
                context.startActivity(intent);
            }

            else if (post.contains("New Deals: Local shopping discounts available now.")) {
                Intent intent = new Intent(context, deals.class);
                context.startActivity(intent);
            }


            else if (post.contains("Tips: Managing home and work balance efficiently.")) {
                Intent intent = new Intent(context, tips.class);
                context.startActivity(intent);
            }

            else if (post.contains("Stay connected: Chat with our community!")) {
                Intent intent = new Intent(context, chat.class);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return communityPosts.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView postTextView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            postTextView = itemView.findViewById(R.id.postTextView);
        }
    }
}
