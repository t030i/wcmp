package com.example.wcmp;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.*;

import java.util.Calendar;

public class Signup extends AppCompatActivity {

    EditText firstname, lastname, dateofbirth, phonenum, username, email, password;
    Button signup, login;
    FirebaseDatabase database;
    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        firstname = findViewById(R.id.firstname);
        lastname = findViewById(R.id.lastname);
        dateofbirth = findViewById(R.id.dateofbirth);
        phonenum = findViewById(R.id.phonenum);
        username = findViewById(R.id.username);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        signup = findViewById(R.id.btn_signup);
        login = findViewById(R.id.btn_login);

        // Date picker
        dateofbirth.setFocusable(false);
        dateofbirth.setOnClickListener(view -> {
            final Calendar calendar = Calendar.getInstance();
            int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH);
            int day = calendar.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog dialog = new DatePickerDialog(Signup.this, (view1, year1, month1, dayOfMonth) -> {
                String dob = (month1 + 1) + "/" + dayOfMonth + "/" + year1;
                dateofbirth.setText(dob);
            }, year, month, day);
            dialog.show();
        });

        signup.setOnClickListener(view -> {
            database = FirebaseDatabase.getInstance("https://wcmp-53d93-default-rtdb.firebaseio.com/");
            reference = database.getReference("users");

            String fn = firstname.getText().toString();
            String ln = lastname.getText().toString();
            String dob = dateofbirth.getText().toString();
            String phn = phonenum.getText().toString();
            String user = username.getText().toString();
            String em = email.getText().toString();
            String pass = password.getText().toString();

            if (fn.isEmpty() || ln.isEmpty() || dob.isEmpty() || phn.isEmpty() ||
                    user.isEmpty() || em.isEmpty() || pass.isEmpty()) {
                Toast.makeText(Signup.this, "Please enter all the fields", Toast.LENGTH_SHORT).show();
            } else if (!em.contains("@") || !em.contains(".com")) {
                email.setError("Enter a valid email (must include @ and .com)");
                email.requestFocus();
            } else {
                reference.child(user).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.exists()) {
                            Toast.makeText(Signup.this, "User already exists", Toast.LENGTH_SHORT).show();
                        } else {
                            HelperClass helperClass = new HelperClass(fn, ln, dob, phn, user, em, pass);
                            reference.child(user).setValue(helperClass);
                            Toast.makeText(Signup.this, "Signup successful, please login", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(Signup.this, Login.class));
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(Signup.this, "Database error", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });

        login.setOnClickListener(view -> startActivity(new Intent(Signup.this, Login.class)));
    }
}
