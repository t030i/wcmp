package com.example.wcmp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class Profile extends AppCompatActivity {

    TextView welcome, username, firstname, lastname, dateofbirth, phonenum, email;
    Button homepage, guidepage , logout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        welcome = findViewById(R.id.welcome_user);
        username = findViewById(R.id.profile_username);
        firstname = findViewById(R.id.profile_firstname);
        lastname = findViewById(R.id.profile_lastname);
        dateofbirth = findViewById(R.id.profile_dateofbirth);
        phonenum = findViewById(R.id.profile_phonenum);
        email = findViewById(R.id.profile_email);

        homepage = findViewById(R.id.homepage1);
        guidepage = findViewById(R.id.helpservice);
        logout = findViewById(R.id.logout);

        homepage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Profile.this, Home.class);
                startActivity(intent);
            }
        });

        guidepage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Profile.this, guidepage.class);
                startActivity(intent);

            }
        });

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Profile.this, Login.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        SharedPreferences prefs = getSharedPreferences("MyPrefs", MODE_PRIVATE);
        String wlc = prefs.getString("firstname", "");
        String user = prefs.getString("username", "");
        String fn = prefs.getString("firstname", "");
        String ln = prefs.getString("lastname", "");
        String dob = prefs.getString("dateofbirth", "");
        String pn = prefs.getString("phonenum", "");
        String em = prefs.getString("email", "");

        Intent intent = getIntent();
        if (intent.hasExtra("firstname")) {
            wlc = intent.getStringExtra("firstname");
            user = intent.getStringExtra("username");
            fn = intent.getStringExtra("firstname");
            ln = intent.getStringExtra("lastname");
            dob = intent.getStringExtra("dateofbirth");
            pn = intent.getStringExtra("phonenum");
            em = intent.getStringExtra("email");

            SharedPreferences.Editor editor = prefs.edit();
            editor.putString("firstname", wlc);
            editor.putString("username", user);
            editor.putString("firstname", fn);
            editor.putString("lastname", ln);
            editor.putString("dateofbirth", dob);
            editor.putString("phonenum", pn);
            editor.putString("email", em);
            editor.apply();
        }

        welcome.setText(wlc);
        username.setText("Username: " + user);
        firstname.setText("First Name: " + fn);
        lastname.setText("Last Name: " + ln);
        dateofbirth.setText("Date of Birth: " + dob);
        phonenum.setText("Phone Number: " + pn);
        email.setText("Email: " + em);


    }
}