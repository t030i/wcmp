package com.example.wcmp;

public class ReportModel {
    public String issue;

    public ReportModel() {
        // Default constructor for Firebase
    }

    public ReportModel(String issue) {
        this.issue = issue;
    }
}

