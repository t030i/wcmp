package com.example.wcmp;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DatabaseReference;

import java.util.List;

public class InfoAdapter extends RecyclerView.Adapter<InfoAdapter.ViewHolder> {

    private final List<InfoItem> items;
    private final DatabaseReference ref;
    private final Context context;

    public InfoAdapter(Context context, List<InfoItem> items, DatabaseReference ref) {
        this.context = context;
        this.items = items;
        this.ref = ref;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView textView;
        public TextView urlView;
        public Button deleteBtn, editBtn;

        public ViewHolder(View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.itemText);
            urlView = itemView.findViewById(R.id.itemUrl);
            deleteBtn = itemView.findViewById(R.id.deleteBtn);
            editBtn = itemView.findViewById(R.id.editBtn);
        }
    }

    @NonNull
    @Override
    public InfoAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.info_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull InfoAdapter.ViewHolder holder, int position) {
        InfoItem item = items.get(position);

        holder.textView.setText(item.getText());

        String url = item.getUrl();
        if (url != null && !url.trim().isEmpty()) {
            holder.urlView.setText(url);
            holder.urlView.setVisibility(View.VISIBLE);
            holder.urlView.setOnClickListener(v -> {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                context.startActivity(browserIntent);
            });
        } else {
            holder.urlView.setVisibility(View.GONE);
        }

        holder.deleteBtn.setOnClickListener(v -> ref.child(item.getId()).removeValue());

        holder.editBtn.setOnClickListener(v -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setTitle("Edit Entry");

            View dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_edit_item, null);
            EditText editText = dialogView.findViewById(R.id.editText);
            EditText editUrl = dialogView.findViewById(R.id.editUrl);

            editText.setText(item.getText());
            editUrl.setText(item.getUrl());

            builder.setView(dialogView);

            builder.setPositiveButton("Update", (dialog, which) -> {
                String newText = editText.getText().toString().trim();
                String newUrl = editUrl.getText().toString().trim();
                if (!newText.isEmpty()) {
                    InfoItem updatedItem = new InfoItem(item.getId(), newText, newUrl);
                    ref.child(item.getId()).setValue(updatedItem);
                }
            });

            builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
            builder.show();
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }
}
