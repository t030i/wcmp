package com.example.wcmp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.*;

import java.util.ArrayList;
import java.util.List;

public class deals extends AppCompatActivity {

    RecyclerView recyclerView;
    DealAdapter adapter;
    List<InfoItem> dealList;
    DatabaseReference dealRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deals);

        Button homeButton = findViewById(R.id.homeButton);
        Button profileButton = findViewById(R.id.profileButton);
        Button helpButton = findViewById(R.id.helpButton);
        recyclerView = findViewById(R.id.recyclerViewDeals);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        dealList = new ArrayList<>();
        adapter = new DealAdapter(this, dealList);
        recyclerView.setAdapter(adapter);

        dealRef = FirebaseDatabase.getInstance().getReference("deals");

        dealRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                dealList.clear();
                for (DataSnapshot child : snapshot.getChildren()) {
                    InfoItem item = child.getValue(InfoItem.class);
                    if (item != null) {
                        dealList.add(item);
                    }
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(deals.this, "Failed to load deals.", Toast.LENGTH_SHORT).show();
            }
        });

        homeButton.setOnClickListener(v -> startActivity(new Intent(deals.this, Home.class)));
        profileButton.setOnClickListener(v -> startActivity(new Intent(deals.this, Profile.class)));
        helpButton.setOnClickListener(v -> startActivity(new Intent(deals.this, guidepage.class)));
    }
}
