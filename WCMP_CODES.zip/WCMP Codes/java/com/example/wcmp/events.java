package com.example.wcmp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class events extends AppCompatActivity {

    RecyclerView recyclerView;
    EventAdapter adapter;
    List<InfoItem> eventList;
    DatabaseReference databaseRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events);

        Button homeButton = findViewById(R.id.homeButton);
        Button profileButton = findViewById(R.id.profileButton);
        Button helpButton = findViewById(R.id.helpButton);
        recyclerView = findViewById(R.id.recyclerViewEvents);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        eventList = new ArrayList<>();
        adapter = new EventAdapter(this, eventList);
        recyclerView.setAdapter(adapter);

        databaseRef = FirebaseDatabase.getInstance().getReference("events");

        // Load events
        databaseRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                eventList.clear();
                for (DataSnapshot child : snapshot.getChildren()) {
                    InfoItem item = child.getValue(InfoItem.class);
                    if (item != null) {
                        eventList.add(item);
                    }
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(events.this, "Failed to load events.", Toast.LENGTH_SHORT).show();
            }
        });

        homeButton.setOnClickListener(v -> startActivity(new Intent(events.this, Home.class)));
        profileButton.setOnClickListener(v -> startActivity(new Intent(events.this, Profile.class)));
        helpButton.setOnClickListener(v -> startActivity(new Intent(events.this, guidepage.class)));
    }
}
