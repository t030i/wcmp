package com.example.wcmp;

public class ChatMessage {
    public String sender;
    public String message;
    public String timestamp;

    public ChatMessage() {
        // Required for Firebase
    }

    public ChatMessage(String sender, String message, String timestamp) {
        this.sender = sender;
        this.message = message;
        this.timestamp = timestamp;
    }
}

