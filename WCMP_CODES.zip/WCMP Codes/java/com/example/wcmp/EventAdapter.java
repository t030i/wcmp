package com.example.wcmp;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class EventAdapter extends RecyclerView.Adapter<EventAdapter.ViewHolder> {

    private final List<InfoItem> events;
    private final Context context;

    public EventAdapter(Context context, List<InfoItem> events) {
        this.context = context;
        this.events = events;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView text;
        Button viewMoreBtn;

        public ViewHolder(View itemView) {
            super(itemView);
            text = itemView.findViewById(R.id.eventItemText);
            viewMoreBtn = itemView.findViewById(R.id.viewMoreButton);
        }
    }

    @NonNull
    @Override
    public EventAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.event_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EventAdapter.ViewHolder holder, int position) {
        InfoItem item = events.get(position);
        holder.text.setText(item.getText());

        holder.viewMoreBtn.setOnClickListener(v -> {
            String url = item.getUrl();
            if (url != null && !url.trim().isEmpty()) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                context.startActivity(intent);
            } else {
                Toast.makeText(context, "No link available for this event.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return events.size();
    }
}
